Scintillar brand kit
====================

logos/   The logo in three layouts: horizontal (default), vertical and mark.
icons/   The mark on a tile, for favicons and app icons.
tokens/  Colors and type as CSS variables and W3C design tokens.

Each file comes as SVG and as PNG at 1x, 2x and 4x.
"on-light" files have dark ink, for light backgrounds.
"on-dark" files have light ink, for dark backgrounds.
"brand" is green; "mono" is a single neutral color, for photos and colored backgrounds.

Use the files as they are: don't redraw, retype, recolor, stretch, rotate or add effects.
Scintillar tools are white-label: you never have to show this logo in a tool you host.

Full guide: https://scintillar.com/en/brand
